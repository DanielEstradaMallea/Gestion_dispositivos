package com.example.gestiondispositivos.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.example.gestiondispositivos.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Registro extends AppCompatActivity {

    EditText correo, contraseña, nombreCompleto;
    Button registrar;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);

        LottieAnimationView lottieAnimationView = findViewById(R.id.lottieAnimationViewBackground);

        lottieAnimationView.setAnimation(R.raw.fondostar);
        lottieAnimationView.setRepeatCount(LottieDrawable.INFINITE);
        lottieAnimationView.playAnimation();

        correo = findViewById(R.id.etCorreoR);
        contraseña = findViewById(R.id.etContraseñaR);

        nombreCompleto = findViewById(R.id.etNombreCompleto);

        registrar = findViewById(R.id.btnRegistrar);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los valores de los campos
                String email = correo.getText().toString().trim();
                String password = contraseña.getText().toString().trim();

                String fullName = nombreCompleto.getText().toString().trim();

                // Verificar que los campos no estén vacíos
                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)  || TextUtils.isEmpty(fullName)) {
                    Toast.makeText(Registro.this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Crear la cuenta si los campos no están vacíos
                firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Registro.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Registro.this, Login.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(Registro.this, "Inténtalo más tarde", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}