package com.example.gestiondispositivos.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.example.gestiondispositivos.R;
import com.example.gestiondispositivos.model.Articulo;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

    private EditText detalleNombre, detalleId, tvBuscar;
    private Button btnBuscar, btnAgregar;
    private ListView lvListModelos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        LottieAnimationView lottieAnimationView = findViewById(R.id.lottieAnimationViewBackground);

        // Configurar la animación
        lottieAnimationView.setAnimation(R.raw.fondostar);
        lottieAnimationView.setRepeatCount(LottieDrawable.INFINITE);
        lottieAnimationView.playAnimation();

        btnBuscar = findViewById(R.id.btnBuscar);
        btnAgregar = findViewById(R.id.btnAgregar);
        tvBuscar = findViewById(R.id.tvBuscar);


        lvListModelos = findViewById(R.id.lvListModelos);

        Buscar();
        Agregar();
        ListarModelos();

    }

    private void ListarModelos() {

        //conectarse a la base de datos
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference dbref = db.getReference(Articulo.class.getSimpleName());
        ArrayList<Articulo> listModelos = new ArrayList<Articulo>();
        ArrayAdapter<Articulo> adaptador = new
                ArrayAdapter<Articulo>(Home.this, R.layout.list_item_nuevo, listModelos);
        lvListModelos.setAdapter(adaptador);
        //aqui creamos un evento que escuche cuando se agregan registros nuevos.
        dbref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String
                    previousChildName) {
                if (snapshot != null && snapshot.getValue() != null) {
                    Articulo modelo = snapshot.getValue(Articulo.class);
                    if (modelo != null) {
                        listModelos.add(modelo);
                        adaptador.notifyDataSetChanged();
                    } else {
                        Log.e("ListarModelos", "El modelo es nulo");
                    }
                } else {
                    Log.e("ListarModelos", "Snapshot o valor nulos");
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String
                    previousChildName) {
                adaptador.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String
                    previousChildName) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        lvListModelos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Articulo modelo = listModelos.get(i);
                AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(Home.this, R.style.AlertDialogCustom));

                View viewInflated = LayoutInflater.from(Home.this).inflate(R.layout.dialog_articulo_detalle, null);


                // Obtener las referencias a los TextView del diseño del diálogo
                TextView txtIdDetalle = viewInflated.findViewById(R.id.txtIdDetalle);
                TextView txtNombreDetalle = viewInflated.findViewById(R.id.txtNombreDetalle);
                TextView txtCategoriaDetalle = viewInflated.findViewById(R.id.txtCategoria);
                TextView txtStockDetalle = viewInflated.findViewById(R.id.txtStock);


                // Establecer los valores en los TextView
                txtIdDetalle.setText(String.valueOf(modelo.getId()));
                txtNombreDetalle.setText(modelo.getNombre());
                txtCategoriaDetalle.setText(modelo.getCategoria());
                txtStockDetalle.setText(String.valueOf(modelo.getStock()));

                builder.setView(viewInflated);
                builder.setCancelable(true);
                builder.setTitle("Detalles");


                builder.setNeutralButton("Modificar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Puedes agregar acciones adicionales aquí si es necesario
                        ModificarArticulo(modelo);
                    }
                });

                builder.setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Agrega aquí la lógica para eliminar el artículo
                        // Puedes utilizar el objeto 'modelo' para obtener la información del artículo a eliminar.
                        // Luego, realiza la eliminación desde Firebase.
                        EliminarArticulo(modelo);
                    }
                });

                AlertDialog dialog = builder.create();

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


                dialog.show();
            }
        });
    }


    private void Agregar() {
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogAgregarArticulo();
            }
        });
    }

    private void mostrarDialogAgregarArticulo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(Home.this, R.style.AlertDialogCustom));
        builder.setTitle("Agregar Artículo");

        // Inflar el diseño personalizado para el Dialog
        View viewInflated = LayoutInflater.from(Home.this).inflate(R.layout.dialog_agregar_articulo, null);
        builder.setView(viewInflated);

        // Obtener referencias a los EditText en el diseño del Dialog
        EditText etId = viewInflated.findViewById(R.id.etId);
        EditText etNombre = viewInflated.findViewById(R.id.etNombre);
        EditText etCategoria = viewInflated.findViewById(R.id.etCategoria);
        EditText etStock = viewInflated.findViewById(R.id.etStock);

        // Configurar el botón "Agregar" en el Dialog
        builder.setPositiveButton("Agregar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {



                if (etId.getText().toString().trim().isEmpty() || etNombre.getText().toString().trim().isEmpty() || etCategoria.getText().toString().trim().isEmpty() || etStock.getText().toString().trim().isEmpty()) {
                    Toast.makeText(Home.this, "Completa los campos", Toast.LENGTH_SHORT).show();

                } else {

                    // Aquí obtienes los valores ingresados en los EditText
                    int id = Integer.parseInt(etId.getText().toString());
                    String nombre = etNombre.getText().toString().trim();
                    String categoria = etCategoria.getText().toString().trim();
                    int stock = Integer.parseInt(etStock.getText().toString());

                    if (nombre.isEmpty() || categoria.isEmpty()) {
                        Toast.makeText(Home.this, "Completa los datos", Toast.LENGTH_SHORT).show();
                    } else {

                        agregarArticulo(id, nombre, categoria, stock);
                    }
                }}
        });

        // Configurar el botón "Cancelar" en el Dialog
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.show();
    }

    private void agregarArticulo(int id, String nombre, String categoria, int stock) {
        // Lógica para agregar el artículo a la base de datos
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference dbref = db.getReference(Articulo.class.getSimpleName());

        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String strId = Integer.toString(id);
                boolean res = false;
                for (DataSnapshot x : snapshot.getChildren()) {
                    if (x.child("id").getValue().toString().equalsIgnoreCase(strId)) {
                        res = true;
                        Toast.makeText(Home.this, "Id " + strId + " ya registrado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                boolean res2 = false;
                for (DataSnapshot x : snapshot.getChildren()) {
                    if (x.child("nombre").getValue().toString().equalsIgnoreCase(nombre)) {
                        res2 = true;
                        Toast.makeText(Home.this, "Artículo " + nombre + " ya registrado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                if (res == false && res2 == false) {
                    Articulo articulo = new Articulo(id, nombre, categoria, stock);
                    dbref.push().setValue(articulo);
                    Toast.makeText(Home.this, "Artículo ingresado correctamente", Toast.LENGTH_SHORT).show();
                    ListarModelos(); // Actualizamos el listview
                } else {
                    Toast.makeText(Home.this, "No se pudo agregar el artículo", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Home.this, "Error al agregar el artículo: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void EliminarArticulo(Articulo articulo) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder confirmDialog = new AlertDialog.Builder(new ContextThemeWrapper(Home.this, R.style.AlertDialogCustom));
                confirmDialog.setTitle("Confirmar eliminación");
                confirmDialog.setMessage("¿Estás seguro de que deseas eliminar este artículo?");
                confirmDialog.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Usuario ha confirmado la eliminación
                        FirebaseDatabase db = FirebaseDatabase.getInstance();
                        DatabaseReference dbref = db.getReference(Articulo.class.getSimpleName());

                        dbref.orderByChild("id").equalTo(articulo.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                                        childSnapshot.getRef().removeValue();
                                    }
                                    Toast.makeText(Home.this, "Articulo eliminado correctamente", Toast.LENGTH_SHORT).show();


                                    ListarModelos(); // Actualizamos el listview
                                } else {
                                    Toast.makeText(Home.this, "No se pudo encontrar el artículo en la base de datos", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(Home.this, "Error al eliminar el artículo: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

                confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Usuario ha cancelado la eliminación
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = confirmDialog.create();

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                dialog.show();
            }
        });
    }

    private void ModificarArticulo(Articulo articulo) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(Home.this, R.style.AlertDialogCustom));
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_modificar_articulo, null);
        dialogBuilder.setView(dialogView);

        EditText etIdModelo = dialogView.findViewById(R.id.etIdModelo);
        EditText etNombreModelo = dialogView.findViewById(R.id.etNombreModelo);
        EditText etCategoria = dialogView.findViewById(R.id.etCategoria);
        EditText etStock = dialogView.findViewById(R.id.etStock);

        // Configurar los EditText con los valores del artículo seleccionado
        etIdModelo.setText(String.valueOf(articulo.getId()));
        etNombreModelo.setText(articulo.getNombre());
        etCategoria.setText(articulo.getCategoria());
        etStock.setText(String.valueOf(articulo.getStock()));


        dialogBuilder.setTitle("Modificar Artículo");
        dialogBuilder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Obtener los nuevos valores de los EditText
                int nuevoId = Integer.parseInt(etIdModelo.getText().toString());
                String nuevoNombre = etNombreModelo.getText().toString();
                String nuevaCategoria = etCategoria.getText().toString();
                int nuevoStock = Integer.parseInt(etStock.getText().toString());

                // Realizar la actualización en la base de datos
                FirebaseDatabase db = FirebaseDatabase.getInstance();
                DatabaseReference dbref = db.getReference(Articulo.class.getSimpleName());

                dbref.orderByChild("id").equalTo(articulo.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                                // Actualizar los valores
                                childSnapshot.getRef().child("id").setValue(nuevoId);
                                childSnapshot.getRef().child("nombre").setValue(nuevoNombre);
                                childSnapshot.getRef().child("categoria").setValue(nuevaCategoria);
                                childSnapshot.getRef().child("stock").setValue(nuevoStock);
                            }
                            Toast.makeText(Home.this, "Artículo modificado correctamente", Toast.LENGTH_SHORT).show();
                            ListarModelos(); // Actualizamos el listview
                        } else {
                            Toast.makeText(Home.this, "No se pudo encontrar el artículo en la base de datos", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(Home.this, "Error al modificar el artículo: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        dialogBuilder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Usuario ha cancelado la modificación
                dialogInterface.dismiss();
            }
        });

        AlertDialog alertDialog = dialogBuilder.create();


        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
    }

    private void Buscar() {
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tvBuscar.getText().toString().trim().isEmpty()) {
                    ocultarTeclado();
                    Toast.makeText(Home.this, "Ingrese el Id a buscar", Toast.LENGTH_LONG).show();
                } else {


                    int id = Integer.parseInt(tvBuscar.getText().toString());
                    FirebaseDatabase db = FirebaseDatabase.getInstance();
                    DatabaseReference dbref = db.getReference(Articulo.class.getSimpleName());


                    // Cambia el evento de escucha para ValueEventListener
                    dbref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String strId = Integer.toString(id);
                            boolean res = false;
                            for (DataSnapshot x : snapshot.getChildren()) {
                                if (strId.equalsIgnoreCase(x.child("id").getValue().toString())) {
                                    res = true;
                                    ocultarTeclado();
                                    // Muestra el artículo encontrado
                                    mostrarVentanaArticulo(x.getValue(Articulo.class));
                                    break;
                                }
                            }
                            if (!res) {
                                ocultarTeclado();
                                Toast.makeText(Home.this, "Id (" + strId + ") no encontrado", Toast.LENGTH_LONG).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            // Manejar errores si es necesario
                        }
                    });
                }
            }
        });
    }

    // Método para mostrar la ventana del artículo encontrado
    private void mostrarVentanaArticulo(Articulo modelo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(Home.this, R.style.AlertDialogCustom));
        builder.setTitle("Articulo encontrado");

        LayoutInflater inflater = LayoutInflater.from(Home.this);
        View view = inflater.inflate(R.layout.dialog_articulo_detalle, null);

        TextView txtId = view.findViewById(R.id.txtIdDetalle);
        TextView txtNombre = view.findViewById(R.id.txtNombreDetalle);
        TextView txtCategoria = view.findViewById(R.id.txtCategoria);
        TextView txtStock = view.findViewById(R.id.txtStock);

        // Establecer los valores del artículo en las vistas
        txtId.setText(String.valueOf(modelo.getId()));
        txtNombre.setText(modelo.getNombre());
        txtCategoria.setText(modelo.getCategoria());
        txtStock.setText(String.valueOf(modelo.getStock()));

        builder.setView(view);

        builder.setNeutralButton("Modificar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                ModificarArticulo(modelo);
            }
        });

        builder.setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Lógica para eliminar el artículo
                EliminarArticulo(modelo);
            }
        });

        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.show();
    }


    private void ocultarTeclado() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}