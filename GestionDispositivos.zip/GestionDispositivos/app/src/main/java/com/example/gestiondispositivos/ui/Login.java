package com.example.gestiondispositivos.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.example.gestiondispositivos.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    TextView tvSignUp;
    EditText correo, password;
    Button ingresar;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Inicializar la animación Lottie del background
        LottieAnimationView lottieAnimationView = findViewById(R.id.lottieAnimationViewBackground);
        LottieAnimationView lottieAnimationView2= findViewById(R.id.lottieAnimationView);


        // Configurar la animación
        lottieAnimationView.setAnimation(R.raw.fondostar);
        lottieAnimationView.setRepeatCount(LottieDrawable.INFINITE);
        lottieAnimationView.playAnimation();

        // Configurar la animación
        lottieAnimationView2.setAnimation(R.raw.signin);
        lottieAnimationView2.setRepeatCount(LottieDrawable.INFINITE);
        lottieAnimationView2.playAnimation();

        correo = findViewById(R.id.tvEmail);
        password = findViewById(R.id.tvPassword);
        ingresar = findViewById(R.id.btnIngresar);


        tvSignUp = findViewById(R.id.tv_sign_up);

        ingresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!correo.getText().toString().isEmpty() || !password.getText().toString().isEmpty())  {

                    firebaseAuth.signInWithEmailAndPassword(correo.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(Login.this, "Login Success", Toast.LENGTH_SHORT).show();

                                Intent i = new Intent(Login.this, Home.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(Login.this, "Usuario y/o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }); }
                else {
                    Toast.makeText(Login.this, "Complete los campos", Toast.LENGTH_SHORT).show();
                }


            }
        });


        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenSignUp();
            }
        });
    }


    public void ScreenSignUp() {
        Intent signUp = new Intent(this, Registro.class);
        startActivity(signUp);
    }



    }
